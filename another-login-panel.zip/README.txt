A Pen created at CodePen.io. You can find this one at https://codepen.io/clein/pen/xnmKL.

 Just another responsive login panel with social buttons.